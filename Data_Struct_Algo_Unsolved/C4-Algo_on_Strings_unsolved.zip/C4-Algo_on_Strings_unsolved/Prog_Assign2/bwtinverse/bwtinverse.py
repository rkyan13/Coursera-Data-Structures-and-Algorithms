# python3
import sys

def InverseBWT(bwt):
    # write your code here
    return ""


if __name__ == '__main__':
    bwt = sys.stdin.readline().strip()
    print(InverseBWT(bwt))