#include <iostream>
#include <string>

using namespace std;

string solve (string p, string q)
{
	string result = p;

	return result;
}

int main (void)
{
	string p;
	cin >> p;
	string q;
	cin >> q;

	string ans = solve (p, q);

	cout << ans << endl;

	return 0;
}
